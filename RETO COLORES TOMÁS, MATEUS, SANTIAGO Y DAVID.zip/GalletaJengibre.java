package dibujobasket;

public class GalletaJengibre {

    private String color;
    private boolean Sombrero;
    private String colorMoño;
    private int cantidadBotones;
    private String expresion;
            
          
    public GalletaJengibre(String color, boolean Sombrero, String colorMoño, int cantidadBotones, String expresion) {
        this.color = color;
        this.Sombrero = Sombrero;
        this.colorMoño = colorMoño;
        this.cantidadBotones = cantidadBotones;
        this.expresion = expresion;
    }

    public GalletaJengibre() {
        this.color = "naranja";
        this.Sombrero = true;
        this.colorMoño = "morado";
        this.cantidadBotones = 2;
        this.expresion = "feliz";
    }

    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }

    public boolean isTieneSombrero() {
        return Sombrero;
    }

    public void setTieneSombrero(boolean tieneSombrero) {
        this.Sombrero = tieneSombrero;
    }

    public String getColorMoño() {
        return colorMoño;
    }

    public void setColorMoño(String colorMoño) {
        this.colorMoño = colorMoño;
    }

    public int getCantidadBotones() {
        return cantidadBotones;
    }

    public void setCantidadBotones(int cantidadBotones) {
        this.cantidadBotones = cantidadBotones;
    }

    public String getExpresion() {
        return expresion;
    }

    public void setExpresion(String expresion) {
        this.expresion = expresion;
    }

    // Métodos adicionales
    public void mostrarInfo() {
        System.out.println("Galleta de color: " + color);
        System.out.println("Tiene sombrero: " + Sombrero);
        System.out.println("Moño color: " + colorMoño);
        System.out.println("Botones: " + cantidadBotones);
        System.out.println("Expresión: " + expresion);
    }

    public void sonreir() {
        this.expresion = "sonriendo";
        System.out.println("está sonriendo");
    }

    public void agregarBoton() {
        this.cantidadBotones++;
    }

    public void quitarSombrero() {
        this.Sombrero = false;
    }

    public String describir() {
        return "una galleta de jengibre con moño " + colorMoño;
    }


    public static void main(String[] args) {
        GalletaJengibre galleta = new GalletaJengibre();

        galleta.mostrarInfo();
        galleta.sonreir();
        galleta.agregarBoton();

        System.out.println(galleta.describir());
    }
}
