package dibujobasket;

public class Main {
    
    public static void main(String[] args) {
        //RELOJ DE JUAN MATEUS
        Reloj r1 = new Reloj();
        r1.setMarca("casio :v");
        System.out.println(r1.getMarca());
        //JUGADOR DE BASKET DE TOMÁS
        DibujoBasket j1 = new DibujoBasket();
        j1.setNombreJugador("Kobe Bryant");
        System.out.println(j1.getNombreJugador());
        //GALLETA DE JENGIBRE DE DAVID
        GalletaJengibre G1 = new GalletaJengibre();
        G1.setColor("rojo");
        System.out.println(G1.getColor());
        //GUITARRA DE SANTIAGO REY
        Guitarra guita1 = new Guitarra();
        guita1.setColorCuerpo("azul");
        System.out.println(guita1.getColorCuerpo());
    }
    
}
