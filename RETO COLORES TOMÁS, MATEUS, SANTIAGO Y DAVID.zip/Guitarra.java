package dibujobasket;

public class Guitarra {
    private String colorCuerpo;
    private String colorDetalle;
    private int cantidadCuerdas;
    private boolean tieneCorriente;
    private double volumen;

    public Guitarra() {
        this.colorCuerpo = "Azul";
        this.colorDetalle = "Rojo";
        this.cantidadCuerdas = 6;
        this.tieneCorriente = false;
        this.volumen = 5.0;
    }

    public Guitarra(String colorCuerpo, String colorDetalle, int cantidadCuerdas) {
        this.colorCuerpo = colorCuerpo;
        this.colorDetalle = colorDetalle;
        this.cantidadCuerdas = cantidadCuerdas;
        this.tieneCorriente = false;
        this.volumen = 0.0;
    }

    public void tocar() {
        System.out.println("La guitarra está vibrando uwu.");
    }

    public void tocar(String nota) {
        System.out.println("Tocando la nota: " + nota);
    }

    public void conectar() {
        this.tieneCorriente = true;
    }

    public void ajustarVolumen(double nuevoVolumen) {
        this.volumen = nuevoVolumen;
    }

    public void saltar() {
        System.out.println("¡La guitarra está saltando de alegría!");
    }

    public String getColorCuerpo() {
        return colorCuerpo;
    }

    public void setColorCuerpo(String colorCuerpo) {
        this.colorCuerpo = colorCuerpo;
    }

    public String getColorDetalle() {
        return colorDetalle;
    }

    public void setColorDetalle(String colorDetalle) {
        this.colorDetalle = colorDetalle;
    }

    public int getCantidadCuerdas() {
        return cantidadCuerdas;
    }

    public void setCantidadCuerdas(int cantidadCuerdas) {
        this.cantidadCuerdas = cantidadCuerdas;
    }

    public boolean isTieneCorriente() {
        return tieneCorriente;
    }

    public void setTieneCorriente(boolean tieneCorriente) {
        this.tieneCorriente = tieneCorriente;
    }

    public double getVolumen() {
        return volumen;
    }

    public void setVolumen(double volumen) {
        this.volumen = volumen;
    }
}
