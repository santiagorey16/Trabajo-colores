package dibujobasket;

public class Reloj {
    public String marca;
    public String tipo;
    public String tipo_de_hora;
    public String Color;
    public String marca_de_zapatos;
    public int num1;
    public String getMarca() {
        return marca;
    }

    public String getTipo() {
        return tipo;
    }

    public String getTipo_de_hora() {
        return tipo_de_hora;
    }

    public String getColor() {
        return Color;
    }

    public String getMarca_de_zapatos() {
        return marca_de_zapatos;
    }

    public void setMarca(String marca) {
        this.marca = marca;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public void setTipo_de_hora(String tipo_de_hora) {
        this.tipo_de_hora = tipo_de_hora;
    }

    public void setColor(String Color) {
        this.Color = Color;
    }

    public void setMarca_de_zapatos(String marca_de_zapatos) {
        this.marca_de_zapatos = marca_de_zapatos;
    }
    public Reloj(){
        this.marca = "sansumg";
        this.tipo = "digital";
        this.marca_de_zapatos = "puma";
        this.Color = "naranja";
        this.tipo_de_hora = "Manecillas";

    }
    public Reloj(String marca, String tipo, String tipo_de_hora, String Color, String marca_de_zapatos) {
        this.marca = marca;
        this.tipo = tipo;
        this.tipo_de_hora = tipo_de_hora;
        this.Color = Color;
        this.marca_de_zapatos = marca_de_zapatos;
    }
    public void Encender(){
        System.out.println("Holi estoy prendido :p");
    }
    public void Apagar(){
        System.out.println("Me estas apagando D:");
    }
    public void Decir_hora(){
        System.out.println("La estas viendo UnU");
    }
    public void Caminar(){
        System.out.println("Camino hacia ti 7w7");
    }
    public void Alarma(){
        System.out.println("ring ring ring :v");
    }
    public void Alarma(int num1){
        System.out.println("tu alarma sonara en 4 horas, a dormir!");
    }
}
