package dibujobasket;

public class DibujoBasket {
    
    String nombreJugador;
    int altura;
    String equipo;
    int edad;
    boolean activo;

    public String getNombreJugador() {
        return nombreJugador;
    }

    public void setNombreJugador(String nombreJugador) {
        this.nombreJugador = nombreJugador;
    }

    public int getAltura() {
        return altura;
    }

    public void setAltura(int altura) {
        this.altura = altura;
    }

    public String getEquipo() {
        return equipo;
    }

    public void setEquipo(String equipo) {
        this.equipo = equipo;
    }

    public int getEdad() {
        return edad;
    }

    public void setEdad(int edad) {
        this.edad = edad;
    }

    public boolean isActivo() {
        return activo;
    }

    public void setActivo(boolean activo) {
        this.activo = activo;
    }
    
    public DibujoBasket() {
        this.nombreJugador = "who";
        this.altura = 200;
        this.equipo = "Furia Santandereana";
        this.edad = 5;
        this.activo = true;
    }

    public DibujoBasket(String nombreJugador, int altura, String equipo, int edad, boolean activo) {
        this.nombreJugador = nombreJugador;
        this.altura = altura;
        this.equipo = equipo;
        this.edad = edad;
        this.activo = activo;
    }
    
    public void jugarPartido() {
        System.out.println("El jugador" + nombreJugador + "se une al partido.");
    }
    
    public void JugarPartido(int tiempo) {
        System.out.println("El jugador" + nombreJugador + "se une al partido en el minuto" + tiempo);
    }
    
    public void encestar() {
        System.out.println(nombreJugador + "hizo una cesta de tres puntos.");
    }
    
    public void patrocinarMarca() {
        System.out.println(nombreJugador + "hizo un comercial para Nike.");
    }
    
    public void tomarAgua() {
        System.out.println(nombreJugador + "está cansado, tomó un receso para tomar agua.");
    }
    
    public void lesion() {
        System.out.println(nombreJugador + "le duele un pelo, ha muerto.");
    }
}

